#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Définition des constantes
#define TAILLE_BUFFER 16
#define MAX_PLAINTES 5

// Structure pour représenter une plainte
typedef struct {
    char contenu[TAILLE_BUFFER];
} Plainte;

// Win
void win() {
    system("cat /flag.txt");
}

// Configuration initiale du programme
void configurer() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
}


// Fonction pour ajouter une plainte
void ajouter_plainte(int *nombre_plaintes, Plainte plaintes[]) {
    if (*nombre_plaintes >= MAX_PLAINTES) {
        printf("Désolé, le nombre maximum de plaintes a été atteint.\n");
        return;
    }

    printf("Entrez votre plainte (max %d caractères): ", TAILLE_BUFFER - 1);
    fgets(plaintes[*nombre_plaintes].contenu, TAILLE_BUFFER, stdin);
    
    // Supprimer le caractère newline si présent
    size_t len = strlen(plaintes[*nombre_plaintes].contenu);
    if (len > 0 && plaintes[*nombre_plaintes].contenu[len-1] == '\n') {
        plaintes[*nombre_plaintes].contenu[len-1] = '\0';
    }

    (*nombre_plaintes)++;
    printf("Plainte ajoutée avec succès.\n");
}

// Fonction pour afficher toutes les plaintes
int afficher_toutes_les_plaintes(int nombre_plaintes, Plainte plaintes[]) {
    if (nombre_plaintes == 0) {
        printf("Il n'y a aucune plainte à afficher.\n");
        return 0;
    }

    printf("Liste des plaintes:\n");
    for (int i = 0; i < nombre_plaintes; i++) {
        printf("%d. %s\n", i, plaintes[i].contenu);
    }
    return 0;
}

// Fonction pour modifier une plainte par index
void modifier_plainte_par_index(int nombre_plaintes, Plainte plaintes[]) {
    if (nombre_plaintes == 0) {
        printf("Il n'y a aucune plainte à modifier.\n");
        return;
    }

    int index;
    printf("Entrez l'index de la plainte à modifier (0-%d): ", nombre_plaintes - 1);
    scanf("%d", &index);
    getchar(); // Pour consommer le caractère newline

    if (index < 0 || index >= nombre_plaintes) {
        printf("Index invalide.\n");
        return;
    }

    // 👀
    printf("Entrez la nouvelle plainte (max %d caractères): ", 16 - 1);
    fgets(plaintes[index].contenu, 0x16, stdin);
    
    // Supprimer le caractère newline si présent
    size_t len = strlen(plaintes[index].contenu);
    if (len > 0 && plaintes[index].contenu[len-1] == '\n') {
        plaintes[index].contenu[len-1] = '\0';
    }

    printf("Plainte modifiée avec succès.\n");
}

void menu() {
    // Affichage du menu
    printf("\n1. Ajouter une plainte\n");
    printf("2. Modifier une plainte\n");
    printf("3. Afficher les plaintes\n");
    printf("0. Quitter\n");
    printf("Votre choix: ");
}

void action(int choix, int *nombre_plaintes, Plainte plaintes[]){
    // Traitement du choix de l'utilisateur
    switch(choix) {
        case 1:
            ajouter_plainte(nombre_plaintes, plaintes);
            break;
        case 2:
            modifier_plainte_par_index(*nombre_plaintes, plaintes);
            break;
        case 3:
            afficher_toutes_les_plaintes(*nombre_plaintes, plaintes);
            break;
        case 0:
            printf("Au revoir!\n");
            break;
        default:
            printf("Choix invalide.\n");
    }
}

void main_logic(){
    // Tableau global pour stocker les plaintes
    struct
    {
        Plainte plaintes[MAX_PLAINTES];
        int nombre_plaintes;
    } locals;
    
    locals.nombre_plaintes = 0;

    int choix;
    do {
        menu();
        scanf("%d", &choix);
        getchar(); // Pour consommer le caractère newline
        action(choix, &(locals.nombre_plaintes), locals.plaintes);
    } while (choix != 0);
}

int main() {
    configurer();
    printf("Système de gestion des plaintes citoyennes\n");
    printf("==========================================\n\n");

    main_logic();

    printf("Bye bye!\n");
    return 0;
}